#!/bin/bash
# To load the modules below call this file as an argument to `source`
module load phdf5/1.10.4
