module purge
module load autoload
module load intel/pe-xe-2018--binary
module load intelmpi/2018--binary
module load zlib/1.2.8--gnu--6.1.0
module load hdf5/1.8.18--intelmpi--2018--binary
module load gnu/7.3.0
module load mkl/2018--binary
