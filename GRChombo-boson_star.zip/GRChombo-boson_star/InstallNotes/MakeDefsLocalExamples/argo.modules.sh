module load gcc/4.9.0
module load openmpi/1.10.2/intel/2016
module load intel-mkl/2017
module load intel/2016
module load gnu-openmpi/phdf5/1.8.17
