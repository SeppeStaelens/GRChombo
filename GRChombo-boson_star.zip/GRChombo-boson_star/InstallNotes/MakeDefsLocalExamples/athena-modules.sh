#!/bin/bash
module load intel/mkl/64/2017.2.174
module load gcc
module load openmpi
module load hdf5

